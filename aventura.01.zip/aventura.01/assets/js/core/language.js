/*==================================================
  AVENTURA PLATFORM v2.0
  Core Language Manager
==================================================*/

'use strict';

window.AVENTURA = window.AVENTURA || {};

AVENTURA.language = (() => {

    let currentLanguage = 'en';
    let initialized = false;
    let eventsBound = false;

    /*----------------------------------------------
      Language Data
    ----------------------------------------------*/

    const getLanguageData = () => {
        return AVENTURA.config?.data?.languages || null;
    };

    const getSupportedLanguages = () => {

        const languageData = getLanguageData();

        if(
            languageData &&
            Array.isArray(languageData.supportedLanguages)
        ){
            return languageData.supportedLanguages;
        }

        const fallbackCodes =
            AVENTURA.config?.localization?.supportedLanguages ||
            ['en', 'ar', 'es'];

        return fallbackCodes.map(code => ({
            code,
            direction: code === 'ar' ? 'rtl' : 'ltr',
            locale:
                code === 'ar'
                    ? 'ar-SA'
                    : code === 'es'
                        ? 'es-ES'
                        : 'en-SA'
        }));

    };

    const getSupportedCodes = () => {
        return getSupportedLanguages()
            .map(language => language.code)
            .filter(Boolean);
    };

    const getLanguageConfig = code => {
        return (
            getSupportedLanguages().find(
                language => language.code === code
            ) || null
        );
    };

    /*----------------------------------------------
      Normalize Language
    ----------------------------------------------*/

    const normalize = language => {

        if(typeof language !== 'string'){
            return null;
        }

        const normalized = language
            .trim()
            .toLowerCase()
            .split('-')[0];

        return getSupportedCodes().includes(normalized)
            ? normalized
            : null;

    };

    /*----------------------------------------------
      Default / Fallback Language
    ----------------------------------------------*/

    const getDefaultLanguage = () => {

        const languageData = getLanguageData();

        return (
            normalize(languageData?.defaultLanguage) ||
            normalize(
                AVENTURA.config?.localization?.defaultLanguage
            ) ||
            'en'
        );

    };

    const getFallbackLanguage = () => {

        const languageData = getLanguageData();

        return (
            normalize(languageData?.fallbackLanguage) ||
            normalize(
                AVENTURA.config?.localization?.fallbackLanguage
            ) ||
            getDefaultLanguage()
        );

    };

    /*----------------------------------------------
      Stored Language
    ----------------------------------------------*/

    const getStoredLanguage = () => {

        const storageKey =
            AVENTURA.config?.storageKeys?.language;

        if(!storageKey){
            return null;
        }

        if(
            AVENTURA.storage &&
            typeof AVENTURA.storage.get === 'function'
        ){
            return normalize(
                AVENTURA.storage.get(storageKey, null)
            );
        }

        try{
            return normalize(
                localStorage.getItem(storageKey)
            );
        }catch(error){
            return null;
        }

    };

    const saveLanguage = language => {

        const storageKey =
            AVENTURA.config?.storageKeys?.language;

        if(!storageKey){
            return false;
        }

        if(
            AVENTURA.storage &&
            typeof AVENTURA.storage.set === 'function'
        ){
            return AVENTURA.storage.set(
                storageKey,
                language
            );
        }

        try{

            localStorage.setItem(storageKey, language);

            return true;

        }catch(error){

            console.warn(
                '[AVENTURA Language] Unable to save language.',
                error
            );

            return false;

        }

    };

    /*----------------------------------------------
      Resolve Initial Language
    ----------------------------------------------*/

    const resolveInitialLanguage = () => {

        const storedLanguage = getStoredLanguage();

        if(storedLanguage){
            return storedLanguage;
        }

        const documentLanguage = normalize(
            document.documentElement.lang
        );

        if(documentLanguage){
            return documentLanguage;
        }

        const browserLanguage = normalize(
            navigator.language
        );

        if(browserLanguage){
            return browserLanguage;
        }

        return getDefaultLanguage();

    };

    /*----------------------------------------------
      Direction
    ----------------------------------------------*/

    const getDirection = language => {

        const languageConfig =
            getLanguageConfig(language);

        return (
            languageConfig?.direction ||
            (language === 'ar' ? 'rtl' : 'ltr')
        );

    };

    /*----------------------------------------------
      Apply Language to Document
    ----------------------------------------------*/

    const applyToDocument = language => {

        const root = document.documentElement;
        const direction = getDirection(language);

        root.lang = language;
        root.dir = direction;

        root.classList.toggle(
            'is-rtl',
            direction === 'rtl'
        );

        root.classList.toggle(
            'is-ltr',
            direction === 'ltr'
        );

        root.dataset.language = language;

        if(document.body){
            document.body.dataset.language = language;
        }

    };

    /*----------------------------------------------
      Update Language Buttons
    ----------------------------------------------*/

    const updateSwitcher = language => {

        const selector =
            AVENTURA.config?.selectors?.languageButton ||
            '[data-language]';

        document
            .querySelectorAll(selector)
            .forEach(button => {

                const buttonLanguage = normalize(
                    button.dataset.language
                );

                const isActive =
                    buttonLanguage === language;

                button.classList.toggle(
                    AVENTURA.config?.classes?.active ||
                    'is-active',
                    isActive
                );

                button.setAttribute(
                    'aria-pressed',
                    String(isActive)
                );

                if(isActive){
                    button.setAttribute(
                        'aria-current',
                        'true'
                    );
                }else{
                    button.removeAttribute(
                        'aria-current'
                    );
                }

            });

    };

    /*----------------------------------------------
      Dispatch Language Event
    ----------------------------------------------*/

    const dispatch = detail => {

        if(
            AVENTURA.events &&
            typeof AVENTURA.events.emit === 'function'
        ){
            AVENTURA.events.emit(
                'language:changed',
                detail
            );
        }

        document.dispatchEvent(
            new CustomEvent(
                'aventura:language-changed',
                { detail }
            )
        );

    };

    /*----------------------------------------------
      Set Language
    ----------------------------------------------*/

    const set = (
        language,
        options = {}
    ) => {

        const {
            persist = true,
            emit = true
        } = options;

        const normalizedLanguage =
            normalize(language);

        if(!normalizedLanguage){

            console.warn(
                `[AVENTURA Language] Unsupported language: "${language}".`
            );

            return false;

        }

        const previousLanguage = currentLanguage;

        currentLanguage = normalizedLanguage;

        applyToDocument(currentLanguage);
        updateSwitcher(currentLanguage);

        if(persist){
            saveLanguage(currentLanguage);
        }

        if(
            emit &&
            previousLanguage !== currentLanguage
        ){
            dispatch({
                language: currentLanguage,
                previousLanguage,
                direction: getDirection(currentLanguage),
                locale: getLocale(currentLanguage)
            });
        }

        return true;

    };

    /*----------------------------------------------
      Resolve Localized Value
    ----------------------------------------------*/

    const resolve = (
        value,
        language = currentLanguage
    ) => {

        if(
            value === null ||
            typeof value === 'undefined'
        ){
            return '';
        }

        if(typeof value === 'string'){
            return value;
        }

        if(
            typeof value !== 'object' ||
            Array.isArray(value)
        ){
            return String(value);
        }

        const normalizedLanguage =
            normalize(language) ||
            currentLanguage;

        const fallbackLanguage =
            getFallbackLanguage();

        return (
            value[normalizedLanguage] ??
            value[fallbackLanguage] ??
            value.en ??
            value.ar ??
            value.es ??
            ''
        );

    };

    /*----------------------------------------------
      Locale
    ----------------------------------------------*/

    const getLocale = (
        language = currentLanguage
    ) => {

        const languageConfig =
            getLanguageConfig(language);

        return (
            languageConfig?.locale ||
            (
                language === 'ar'
                    ? 'ar-SA'
                    : language === 'es'
                        ? 'es-ES'
                        : 'en-SA'
            )
        );

    };

    /*----------------------------------------------
      Bind Switcher Events
    ----------------------------------------------*/

    const bindEvents = () => {

        if(eventsBound){
            return;
        }

        document.addEventListener(
            'click',
            event => {

                const selector =
                    AVENTURA.config
                        ?.selectors
                        ?.languageButton ||
                    '[data-language]';

                const target = event.target;

                if(!(target instanceof Element)){
                    return;
                }

                const button = target.closest(selector);

                if(!button){
                    return;
                }

                const language =
                    button.dataset.language;

                if(!normalize(language)){
                    return;
                }

                event.preventDefault();

                set(language);

            }
        );

        eventsBound = true;

    };

    /*----------------------------------------------
      Initialize
    ----------------------------------------------*/

    const init = () => {

        if(initialized){
            updateSwitcher(currentLanguage);
            return currentLanguage;
        }

        bindEvents();

        const initialLanguage =
            resolveInitialLanguage();

        set(initialLanguage, {
            persist: false,
            emit: false
        });

        initialized = true;

        return currentLanguage;

    };

    /*----------------------------------------------
      Public API
    ----------------------------------------------*/

    return {
        init,
        set,
        resolve,
        normalize,
        getLocale,
        getDirection,
        getSupportedLanguages,
        getLanguageConfig,

        get current(){
            return currentLanguage;
        },

        get direction(){
            return getDirection(currentLanguage);
        },

        get locale(){
            return getLocale(currentLanguage);
        },

        get isRTL(){
            return getDirection(currentLanguage) === 'rtl';
        },

        get isInitialized(){
            return initialized;
        }
    };

})();