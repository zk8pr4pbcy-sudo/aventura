/*==================================================
  AVENTURA PLATFORM v2.0
  Language Module
==================================================*/

'use strict';

window.AVENTURA = window.AVENTURA || {};

AVENTURA.language = (() => {

    const { $$, addClass, removeClass } = AVENTURA.helpers;
    const { emit } = AVENTURA.events;
    const config = AVENTURA.config;

    const supportedLanguages = ['ar', 'en', 'es'];
    const defaultLanguage = 'en';

    let currentLanguage = defaultLanguage;
    let switchers = [];

    /*----------------------------------------------
      Init
    ----------------------------------------------*/

    const init = () => {

        switchers = $$('[data-language]');

        currentLanguage = getStoredLanguage() || getDocumentLanguage();

        setLanguage(currentLanguage, false);

        bindEvents();

    };

    /*----------------------------------------------
      Get Language
    ----------------------------------------------*/

    const getStoredLanguage = () =>
        localStorage.getItem(config.storageKeys.language);

    const getDocumentLanguage = () => {

        const lang = document.documentElement.lang || defaultLanguage;

        return supportedLanguages.includes(lang) ? lang : defaultLanguage;

    };

    /*----------------------------------------------
      Bind Events
    ----------------------------------------------*/

    const bindEvents = () => {

        switchers.forEach(button => {

            button.addEventListener('click', () => {

                const lang = button.dataset.language;

                if(!supportedLanguages.includes(lang)) return;

                setLanguage(lang);

            });

        });

    };

    /*----------------------------------------------
      Set Language
    ----------------------------------------------*/

    const setLanguage = (lang, save = true) => {

        if(!supportedLanguages.includes(lang)) return;

        currentLanguage = lang;

        document.documentElement.lang = lang;
        document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';

        updateActiveState();

        if(save){
            localStorage.setItem(config.storageKeys.language, lang);
        }

        emit('language:change', {
            language: lang,
            direction: document.documentElement.dir
        });

    };

    /*----------------------------------------------
      Active State
    ----------------------------------------------*/

    const updateActiveState = () => {

        switchers.forEach(button => {

            const isActive = button.dataset.language === currentLanguage;

            if(isActive){
                addClass(button, 'is-active');
                button.setAttribute('aria-pressed', 'true');
            }else{
                removeClass(button, 'is-active');
                button.setAttribute('aria-pressed', 'false');
            }

        });

    };

    /*----------------------------------------------
      Return
    ----------------------------------------------*/

    return {
        init,
        set: setLanguage,
        get: () => currentLanguage
    };

})();