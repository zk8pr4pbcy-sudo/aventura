/*==================================================
  AVENTURA PLATFORM v2.0
  Animations Module
==================================================*/

'use strict';

window.AVENTURA = window.AVENTURA || {};

AVENTURA.animations = (() => {

    const { $$, addClass } = AVENTURA.helpers;
    const { emit } = AVENTURA.events;

    let revealElements = [];
    let observer = null;

    /*----------------------------------------------
      Init
    ----------------------------------------------*/

    const init = () => {

        revealElements = $$('[data-reveal]');

        if(!revealElements.length) return;

        if(prefersReducedMotion()){
            revealElements.forEach(element => addClass(element, 'is-visible'));
            return;
        }

        createObserver();

    };

    /*----------------------------------------------
      Reduced Motion
    ----------------------------------------------*/

    const prefersReducedMotion = () =>
        window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    /*----------------------------------------------
      Observer
    ----------------------------------------------*/

    const createObserver = () => {

        observer = new IntersectionObserver(entries => {

            entries.forEach(entry => {

                if(!entry.isIntersecting) return;

                addClass(entry.target, 'is-visible');

                observer.unobserve(entry.target);

                emit('animation:reveal', {
                    element: entry.target
                });

            });

        }, {
            threshold: 0.16,
            rootMargin: '0px 0px -40px 0px'
        });

        revealElements.forEach(element => {
            observer.observe(element);
        });

    };

    /*----------------------------------------------
      Destroy
    ----------------------------------------------*/

    const destroy = () => {

        if(observer){
            observer.disconnect();
            observer = null;
        }

    };

    /*----------------------------------------------
      Return
    ----------------------------------------------*/

    return {
        init,
        destroy
    };

})();