/*==================================================
  AVENTURA PLATFORM v2.0
  Core Events
==================================================*/

'use strict';

window.AVENTURA = window.AVENTURA || {};

AVENTURA.events = (() => {

    const events = {};

    /*----------------------------------------------
      Subscribe
    ----------------------------------------------*/

    const on = (eventName, callback) => {

        if(!eventName || typeof callback !== 'function') return;

        events[eventName] = events[eventName] || [];

        events[eventName].push(callback);

    };

    /*----------------------------------------------
      Unsubscribe
    ----------------------------------------------*/

    const off = (eventName, callback) => {

        if(!events[eventName]) return;

        events[eventName] = events[eventName].filter(
            fn => fn !== callback
        );

    };

    /*----------------------------------------------
      Emit
    ----------------------------------------------*/

    const emit = (eventName, payload = {}) => {

        if(!events[eventName]) return;

        events[eventName].forEach(callback => {

            try{

                callback(payload);

            }catch(error){

                console.error(
                    `[AVENTURA Event Error]: ${eventName}`,
                    error
                );

            }

        });

    };

    /*----------------------------------------------
      Once
    ----------------------------------------------*/

    const once = (eventName, callback) => {

        const wrapper = payload => {

            callback(payload);

            off(eventName, wrapper);

        };

        on(eventName, wrapper);

    };

    /*----------------------------------------------
      Clear
    ----------------------------------------------*/

    const clear = eventName => {

        if(eventName){

            delete events[eventName];

            return;

        }

        Object.keys(events).forEach(key => delete events[key]);

    };

    /*----------------------------------------------
      Return
    ----------------------------------------------*/

    return {

        on,
        off,
        emit,
        once,
        clear

    };

})();