/*==================================================
  AVENTURA PLATFORM v2.0
  Core Data Loader
==================================================*/

'use strict';

window.AVENTURA = window.AVENTURA || {};

AVENTURA.loader = (() => {

    const cache = new Map();

    let loadingPromise = null;
    let loaded = false;

    /*----------------------------------------------
      Fetch JSON
    ----------------------------------------------*/

    const fetchJson = async url => {

        if(typeof url !== 'string' || !url.trim()){
            throw new TypeError(
                '[AVENTURA Loader] A valid JSON URL is required.'
            );
        }

        if(cache.has(url)){
            return cache.get(url);
        }

        const response = await fetch(url, {
            method: 'GET',
            headers: {
                Accept: 'application/json'
            },
            cache: 'no-cache'
        });

        if(!response.ok){
            throw new Error(
                `[AVENTURA Loader] Failed to load "${url}". ` +
                `HTTP status: ${response.status}`
            );
        }

        let result;

        try{
            result = await response.json();
        }catch(error){
            throw new Error(
                `[AVENTURA Loader] Invalid JSON in "${url}".`
            );
        }

        cache.set(url, result);

        return result;
    };

    /*----------------------------------------------
      Validate Source
    ----------------------------------------------*/

    const validateSource = name => {

        const sources = AVENTURA.config?.dataSources;

        if(!sources){
            throw new Error(
                '[AVENTURA Loader] AVENTURA.config.dataSources is missing.'
            );
        }

        if(!Object.prototype.hasOwnProperty.call(sources, name)){
            throw new Error(
                `[AVENTURA Loader] Unknown data source: "${name}".`
            );
        }

        return sources[name];
    };

    /*----------------------------------------------
      Load Single Source
    ----------------------------------------------*/

    const load = async name => {

        const url = validateSource(name);
        const result = await fetchJson(url);

        AVENTURA.config.data[name] = result;

        return result;
    };

    /*----------------------------------------------
      Dispatch Loader Event
    ----------------------------------------------*/

    const dispatch = (eventName, detail) => {

        if(
            AVENTURA.events &&
            typeof AVENTURA.events.emit === 'function'
        ){
            AVENTURA.events.emit(eventName, detail);
        }

        document.dispatchEvent(
            new CustomEvent(
                `aventura:${eventName.replaceAll(':', '-')}`,
                { detail }
            )
        );

    };

    /*----------------------------------------------
      Load All Sources
    ----------------------------------------------*/

    const loadAll = async () => {

        if(loaded){
            return AVENTURA.config.data;
        }

        if(loadingPromise){
            return loadingPromise;
        }

        loadingPromise = (async () => {

            const root = document.documentElement;
            const sources = AVENTURA.config?.dataSources;

            if(!sources){
                throw new Error(
                    '[AVENTURA Loader] Data sources are not configured.'
                );
            }

            root.classList.remove('data-loaded', 'data-error');
            root.classList.add('data-loading');

            dispatch('data:loading', {
                sources: Object.keys(sources)
            });

            try{

                const names = Object.keys(sources);

                const results = await Promise.allSettled(
                    names.map(name => load(name))
                );

                const failures = [];

                results.forEach((result, index) => {

                    if(result.status === 'rejected'){
                        failures.push({
                            name: names[index],
                            error: result.reason
                        });
                    }

                });

                if(failures.length){

                    failures.forEach(item => {
                        console.error(
                            `[AVENTURA Loader] "${item.name}" failed:`,
                            item.error
                        );
                    });

                    loaded = false;
                    root.classList.add('data-error');

                    dispatch('data:error', {
                        data: AVENTURA.config.data,
                        failures
                    });

                    throw new Error(
                        `[AVENTURA Loader] ${failures.length} ` +
                        'data source(s) failed to load.'
                    );
                }

                loaded = true;
                root.classList.add('data-loaded');

                dispatch('data:loaded', AVENTURA.config.data);

                return AVENTURA.config.data;

            }finally{

                root.classList.remove('data-loading');
                loadingPromise = null;

            }

        })();

        return loadingPromise;
    };

    /*----------------------------------------------
      Get Loaded Data
    ----------------------------------------------*/

    const get = name => {

        if(typeof name === 'undefined'){
            return AVENTURA.config.data;
        }

        if(
            !Object.prototype.hasOwnProperty.call(
                AVENTURA.config.data,
                name
            )
        ){
            return null;
        }

        return AVENTURA.config.data[name];
    };

    /*----------------------------------------------
      Reload Source
    ----------------------------------------------*/

    const reload = async name => {

        const url = validateSource(name);

        cache.delete(url);
        AVENTURA.config.data[name] = null;

        const result = await load(name);

        loaded = Object.values(
            AVENTURA.config.data
        ).every(value => value !== null);

        dispatch('data:reloaded', {
            name,
            data: result
        });

        return result;
    };

    /*----------------------------------------------
      Clear Data and Cache
    ----------------------------------------------*/

    const clear = () => {

        cache.clear();

        Object.keys(AVENTURA.config.data).forEach(name => {
            AVENTURA.config.data[name] = null;
        });

        loaded = false;
        loadingPromise = null;

        document.documentElement.classList.remove(
            'data-loading',
            'data-loaded',
            'data-error'
        );

        dispatch('data:cleared', null);
    };

    /*----------------------------------------------
      Public API
    ----------------------------------------------*/

    return {
        fetchJson,
        load,
        loadAll,
        get,
        reload,
        clear,

        get isLoaded(){
            return loaded;
        },

        get isLoading(){
            return loadingPromise !== null;
        }
    };

})();