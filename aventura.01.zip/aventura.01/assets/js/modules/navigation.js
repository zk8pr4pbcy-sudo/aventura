/*==================================================
  AVENTURA PLATFORM v2.0
  Navigation Module
==================================================*/

'use strict';

window.AVENTURA = window.AVENTURA || {};

AVENTURA.navigation = (() => {

    const { $, $$, addClass, removeClass, hasClass } = AVENTURA.helpers;
    const { emit } = AVENTURA.events;
    const config = AVENTURA.config;
    const cls = config.classes;

    let nav;
    let toggle;
    let close;
    let dropdowns;
    let isOpen = false;

    /*----------------------------------------------
      Init
    ----------------------------------------------*/

    const init = () => {

        nav = $(config.selectors.nav);
        toggle = $(config.selectors.navToggle);
        close = $(config.selectors.navClose);
        dropdowns = $$(config.selectors.dropdown);

        if(!nav) return;

        bindEvents();
        setupAccessibility();

    };

    /*----------------------------------------------
      Bind Events
    ----------------------------------------------*/

    const bindEvents = () => {

        if(toggle){
            toggle.addEventListener('click', openNavigation);
        }

        if(close){
            close.addEventListener('click', closeNavigation);
        }

        dropdowns.forEach(dropdown => {
            bindDropdown(dropdown);
        });

        document.addEventListener('click', handleOutsideClick);
        document.addEventListener('keydown', handleKeydown);
        window.addEventListener('resize', handleResize);

    };

    /*----------------------------------------------
      Accessibility
    ----------------------------------------------*/

    const setupAccessibility = () => {

        if(toggle){
            toggle.setAttribute('aria-controls', nav.id || 'site-navigation');
            toggle.setAttribute('aria-expanded', 'false');
        }

        if(!nav.id){
            nav.id = 'site-navigation';
        }

        dropdowns.forEach(dropdown => {

            const trigger = $('[data-dropdown-trigger]', dropdown);
            const menu = $('[data-dropdown-menu]', dropdown);

            if(trigger && menu){

                const menuId = menu.id || `dropdown-${Math.random().toString(36).slice(2,8)}`;
                menu.id = menuId;

                trigger.setAttribute('aria-controls', menuId);
                trigger.setAttribute('aria-expanded', 'false');

            }

        });

    };

    /*----------------------------------------------
      Open / Close Navigation
    ----------------------------------------------*/

    const openNavigation = () => {

        if(isOpen) return;

        isOpen = true;

        addClass(nav, cls.open);
        addClass(document.body, cls.locked);

        if(toggle){
            toggle.setAttribute('aria-expanded', 'true');
        }

        emit('navigation:open');

    };

    const closeNavigation = () => {

        if(!isOpen) return;

        isOpen = false;

        removeClass(nav, cls.open);
        removeClass(document.body, cls.locked);

        closeAllDropdowns();

        if(toggle){
            toggle.setAttribute('aria-expanded', 'false');
        }

        emit('navigation:close');

    };

    /*----------------------------------------------
      Dropdowns
    ----------------------------------------------*/

    const bindDropdown = dropdown => {

        const trigger = $('[data-dropdown-trigger]', dropdown);

        if(!trigger) return;

        trigger.addEventListener('click', event => {

            event.preventDefault();
            event.stopPropagation();

            toggleDropdown(dropdown);

        });

    };

    const toggleDropdown = dropdown => {

        if(hasClass(dropdown, cls.open)){
            closeDropdown(dropdown);
            return;
        }

        closeAllDropdowns();
        openDropdown(dropdown);

    };

    const openDropdown = dropdown => {

        addClass(dropdown, cls.open);

        const trigger = $('[data-dropdown-trigger]', dropdown);

        if(trigger){
            trigger.setAttribute('aria-expanded', 'true');
        }

    };

    const closeDropdown = dropdown => {

        removeClass(dropdown, cls.open);

        const trigger = $('[data-dropdown-trigger]', dropdown);

        if(trigger){
            trigger.setAttribute('aria-expanded', 'false');
        }

    };

    const closeAllDropdowns = () => {

        dropdowns.forEach(dropdown => {
            closeDropdown(dropdown);
        });

    };

    /*----------------------------------------------
      Outside Click
    ----------------------------------------------*/

    const handleOutsideClick = event => {

        if(nav && !nav.contains(event.target) && !toggle?.contains(event.target)){
            closeNavigation();
            closeAllDropdowns();
        }

    };

    /*----------------------------------------------
      Keyboard
    ----------------------------------------------*/

    const handleKeydown = event => {

        if(event.key === 'Escape'){
            closeNavigation();
            closeAllDropdowns();
        }

    };

    /*----------------------------------------------
      Resize
    ----------------------------------------------*/

    const handleResize = () => {

        if(window.innerWidth >= config.breakpoints.md){
            closeNavigation();
        }

    };

    /*----------------------------------------------
      Return
    ----------------------------------------------*/

    return {
        init,
        open: openNavigation,
        close: closeNavigation
    };

})();