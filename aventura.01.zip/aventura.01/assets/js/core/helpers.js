/*==================================================
  AVENTURA PLATFORM v2.0
  Core Helpers
==================================================*/

'use strict';

window.AVENTURA = window.AVENTURA || {};

AVENTURA.helpers = (() => {

    /*----------------------------------------------
      Query Helpers
    ----------------------------------------------*/

    const $ = (selector, scope = document) =>
        scope.querySelector(selector);

    const $$ = (selector, scope = document) =>
        [...scope.querySelectorAll(selector)];

    /*----------------------------------------------
      Class Helpers
    ----------------------------------------------*/

    const addClass = (element, className) => {
        if(element) element.classList.add(className);
    };

    const removeClass = (element, className) => {
        if(element) element.classList.remove(className);
    };

    const toggleClass = (element, className) => {
        if(element) element.classList.toggle(className);
    };

    const hasClass = (element, className) =>
        element ? element.classList.contains(className) : false;

    /*----------------------------------------------
      Attribute Helpers
    ----------------------------------------------*/

    const getAttr = (element, attribute) =>
        element ? element.getAttribute(attribute) : null;

    const setAttr = (element, attribute, value) => {
        if(element) element.setAttribute(attribute, value);
    };

    const removeAttr = (element, attribute) => {
        if(element) element.removeAttribute(attribute);
    };

    /*----------------------------------------------
      Visibility
    ----------------------------------------------*/

    const show = element => {
        if(element) element.hidden = false;
    };

    const hide = element => {
        if(element) element.hidden = true;
    };

    /*----------------------------------------------
      Events
    ----------------------------------------------*/

    const on = (element, event, callback, options = false) => {
        if(element)
            element.addEventListener(event, callback, options);
    };

    const off = (element, event, callback) => {
        if(element)
            element.removeEventListener(event, callback);
    };

    /*----------------------------------------------
      Debounce
    ----------------------------------------------*/

    const debounce = (callback, delay = 250) => {

        let timer;

        return (...args) => {

            clearTimeout(timer);

            timer = setTimeout(() => {

                callback(...args);

            }, delay);

        };

    };

    /*----------------------------------------------
      Throttle
    ----------------------------------------------*/

    const throttle = (callback, delay = 250) => {

        let waiting = false;

        return (...args) => {

            if(waiting) return;

            callback(...args);

            waiting = true;

            setTimeout(() => {

                waiting = false;

            }, delay);

        };

    };

    /*----------------------------------------------
      Scroll
    ----------------------------------------------*/

    const scrollToElement = element => {

        if(!element) return;

        element.scrollIntoView({

            behavior: 'smooth',

            block: 'start'

        });

    };

    /*----------------------------------------------
      Random ID
    ----------------------------------------------*/

    const uid = (prefix = 'id') =>
        `${prefix}-${Math.random().toString(36).slice(2,10)}`;

    /*----------------------------------------------
      Return
    ----------------------------------------------*/

    return {

        $,
        $$,

        addClass,
        removeClass,
        toggleClass,
        hasClass,

        getAttr,
        setAttr,
        removeAttr,

        show,
        hide,

        on,
        off,

        debounce,
        throttle,

        scrollToElement,

        uid

    };

})();