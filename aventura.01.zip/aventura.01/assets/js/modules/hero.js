/*==================================================
  AVENTURA PLATFORM v2.0
  Hero Module
==================================================*/

'use strict';

window.AVENTURA = window.AVENTURA || {};

AVENTURA.hero = (() => {

    const { $$, addClass } = AVENTURA.helpers;
    const { emit } = AVENTURA.events;

    let heroes = [];

    /*----------------------------------------------
      Init
    ----------------------------------------------*/

    const init = () => {

        heroes = $$('[data-hero]');

        if(!heroes.length) return;

        setupHeroes();
        bindEvents();

    };

    /*----------------------------------------------
      Setup
    ----------------------------------------------*/

    const setupHeroes = () => {

        heroes.forEach(hero => {

            addClass(hero, 'is-ready');

            const media = hero.querySelector('video');

            if(media){
                setupVideo(media);
            }

        });

        emit('hero:ready', {
            count: heroes.length
        });

    };

    /*----------------------------------------------
      Video Setup
    ----------------------------------------------*/

    const setupVideo = video => {

        video.muted = true;
        video.playsInline = true;

        const playPromise = video.play();

        if(playPromise !== undefined){

            playPromise.catch(() => {
                video.setAttribute('data-paused', 'true');
            });

        }

    };

    /*----------------------------------------------
      Parallax
    ----------------------------------------------*/

    const updateParallax = () => {

        const scrollY = window.scrollY || window.pageYOffset;

        heroes.forEach(hero => {

            const background = hero.querySelector('[data-hero-bg]');

            if(!background) return;

            const speed = parseFloat(hero.dataset.parallaxSpeed || '0.18');

            background.style.transform = `translateY(${scrollY * speed}px)`;

        });

    };

    /*----------------------------------------------
      Bind Events
    ----------------------------------------------*/

    const bindEvents = () => {

        if(window.matchMedia('(prefers-reduced-motion: reduce)').matches){
            return;
        }

        window.addEventListener('scroll', () => {
            window.requestAnimationFrame(updateParallax);
        }, {
            passive:true
        });

    };

    /*----------------------------------------------
      Return
    ----------------------------------------------*/

    return {
        init,
        update: updateParallax
    };

})();