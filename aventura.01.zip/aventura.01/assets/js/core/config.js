/*==================================================
  AVENTURA PLATFORM v2.0
  Core Configuration
==================================================*/

'use strict';

window.AVENTURA = window.AVENTURA || {};

AVENTURA.config = {

    /*----------------------------------------------
      Application
    ----------------------------------------------*/

    appName: 'AVENTURA',
    version: '2.0.0',
    environment: 'production',

    /*----------------------------------------------
      Data Sources
    ----------------------------------------------*/

    dataSources: Object.freeze({
        settings: '../../Common/data/settings.json',
        languages: '../../Common/data/languages.json',
        navigation: '../../Common/data/navigation.json',
        footer: '../../Common/data/footer.json',
        experiences: '../../Common/data/experiences.json',
        events: '../../Common/data/events.json',
        services: '../../Common/data/services.json',
        collection: '../../Common/data/collection.json',
        recommendations: '../../Common/data/recommendations.json'
    }),

    /*----------------------------------------------
      Runtime Data
    ----------------------------------------------*/

    data: {
        settings: null,
        languages: null,
        navigation: null,
        footer: null,
        experiences: null,
        events: null,
        services: null,
        collection: null,
        recommendations: null
    },

    /*----------------------------------------------
      Localization
    ----------------------------------------------*/

    localization: {
        defaultLanguage: 'en',
        fallbackLanguage: 'en',
        supportedLanguages: [
            'en',
            'ar',
            'es'
        ]
    },

    get currentLanguage() {

        const storageKey = this.storageKeys.language;

        try {

            const savedLanguage = localStorage.getItem(storageKey);

            if(
                savedLanguage &&
                this.localization.supportedLanguages.includes(savedLanguage)
            ){
                return savedLanguage;
            }

        } catch(error) {

            console.warn(
                '[AVENTURA Config] Unable to read language from storage.',
                error
            );

        }

        const documentLanguage = document.documentElement.lang;

        if(
            documentLanguage &&
            this.localization.supportedLanguages.includes(documentLanguage)
        ){
            return documentLanguage;
        }

        return this.localization.defaultLanguage;
    },

    get rtl() {
        return this.currentLanguage === 'ar';
    },

    /*----------------------------------------------
      Selectors
    ----------------------------------------------*/

    selectors: Object.freeze({
        body: 'body',

        header: '[data-header]',

        nav: '[data-nav]',
        navToggle: '[data-nav-toggle]',
        navClose: '[data-nav-close]',

        dropdown: '[data-dropdown]',
        dropdownTrigger: '[data-dropdown-trigger]',
        dropdownMenu: '[data-dropdown-menu]',

        modal: '[data-modal]',
        modalOpen: '[data-modal-open]',
        modalClose: '[data-modal-close]',

        tabs: '[data-tabs]',
        accordion: '[data-accordion]',

        form: '[data-form]',
        gallery: '[data-gallery]',

        languageSwitcher: '[data-language-switcher]',
        languageButton: '[data-language]',

        recommendations: '[data-recommendations]',
        collectionGrid: '[data-collection-grid]',

        backToTop: '[data-back-to-top]'
    }),

    /*----------------------------------------------
      CSS Classes
    ----------------------------------------------*/

    classes: Object.freeze({
        active: 'is-active',
        open: 'is-open',
        visible: 'is-visible',
        hidden: 'is-hidden',

        loading: 'is-loading',
        loaded: 'is-loaded',

        disabled: 'is-disabled',
        scrolled: 'is-scrolled',
        locked: 'is-locked',

        error: 'is-error',
        success: 'is-success'
    }),

    /*----------------------------------------------
      Breakpoints
    ----------------------------------------------*/

    breakpoints: Object.freeze({
        xs: 576,
        sm: 768,
        md: 992,
        lg: 1200,
        xl: 1400
    }),

    /*----------------------------------------------
      Timings
    ----------------------------------------------*/

    timings: Object.freeze({
        fast: 180,
        normal: 300,
        slow: 600,
        debounce: 250,
        toast: 5000
    }),

    /*----------------------------------------------
      Storage
    ----------------------------------------------*/

    storageKeys: Object.freeze({
        language: 'aventura_language',
        theme: 'aventura_theme',
        cookieConsent: 'aventura_cookie_consent',
        inquiryCart: 'aventura_inquiry_cart'
    }),

    /*----------------------------------------------
      Page Paths
    ----------------------------------------------*/

    paths: Object.freeze({
        home: '../Home/',
        about: '../About/',
        experiences: '../Experiences/',
        events: '../Events/',
        services: '../Services/',
        collection: '../Collection/',
        gallery: '../Gallery/',
        partners: '../Partners/',
        faq: '../FAQ/',
        contact: '../Contact/'
    }),

    /*----------------------------------------------
      Feature Flags
    ----------------------------------------------*/

    features: {
        experiences: true,
        events: true,
        services: true,
        collection: true,
        recommendations: true,
        gallery: true,
        partners: true,
        faq: true,

        journal: false,
        onlinePayment: false,
        customerAccounts: false
    }

};