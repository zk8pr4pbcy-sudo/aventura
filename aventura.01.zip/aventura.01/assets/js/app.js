/*==================================================
  AVENTURA PLATFORM v2.0
  Application Bootstrap
==================================================*/

'use strict';

window.AVENTURA = window.AVENTURA || {};

(() => {

    let initialized = false;

    /*----------------------------------------------
      Dispatch Application Event
    ----------------------------------------------*/

    const dispatch = (eventName, detail = null) => {

        if(
            AVENTURA.events &&
            typeof AVENTURA.events.emit === 'function'
        ){
            AVENTURA.events.emit(eventName, detail);
        }

        document.dispatchEvent(
            new CustomEvent(
                `aventura:${eventName.replace(/:/g, '-')}`,
                { detail }
            )
        );

    };

    /*----------------------------------------------
      Validate Core Files
    ----------------------------------------------*/

    const validateCore = () => {

        const requiredCore = [
            'config',
            'helpers',
            'dom',
            'events',
            'loader',
            'storage',
            'language',
            'includes'
        ];

        const missingCore = requiredCore.filter(
            name => !AVENTURA[name]
        );

        if(missingCore.length){

            throw new Error(
                `[AVENTURA App] Missing core module(s): ` +
                missingCore.join(', ')
            );

        }

    };

    /*----------------------------------------------
      Initialize Single Module
    ----------------------------------------------*/

    const initializeModule = module => {

        if(
            !module ||
            typeof module.init !== 'function'
        ){
            return false;
        }

        try{

            module.init();

            return true;

        }catch(error){

            console.error(
                '[AVENTURA App] Module initialization failed:',
                error
            );

            return false;

        }

    };

    /*----------------------------------------------
      Initialize Website Modules
    ----------------------------------------------*/

    const initializeModules = () => {

        const modules = [
            AVENTURA.navigation,
            AVENTURA.header,
            AVENTURA.hero,
            AVENTURA.animations,
            AVENTURA.modal,
            AVENTURA.forms,
            AVENTURA.booking,
            AVENTURA.gallery,
            AVENTURA.recommendations,
            AVENTURA.collection,
            AVENTURA.services,
            AVENTURA.experiences,
            AVENTURA.eventManager,
            AVENTURA.footer
        ];

        return modules.map(initializeModule);

    };

    /*----------------------------------------------
      Initialize Application
    ----------------------------------------------*/

    const init = async () => {

        if(initialized){
            return;
        }

        initialized = true;

        const root = document.documentElement;

        root.classList.remove(
            'app-ready',
            'app-error'
        );

        root.classList.add('app-loading');

        try{

            validateCore();

            console.info(
                `%c${AVENTURA.config.appName} v${AVENTURA.config.version}`,
                'color:#C8A35E;font-weight:bold;font-size:14px;'
            );

            dispatch('app:loading');

            /*
             * تحميل جميع ملفات JSON أولًا.
             */
            await AVENTURA.loader.loadAll();

            /*
             * تحديد اللغة والاتجاه بعد تحميل languages.json.
             */
            AVENTURA.language.init();

            /*
             * تحميل الهيدر والفوتر والمكونات المشتركة.
             */
            await AVENTURA.includes.load();

            /*
             * تشغيل وحدات الموقع بعد ظهور المكونات في الصفحة.
             */
            initializeModules();

            root.classList.add('app-ready');

            dispatch('app:ready', {
                language: AVENTURA.language.current,
                direction: AVENTURA.language.direction,
                data: AVENTURA.config.data
            });

        }catch(error){

            initialized = false;

            root.classList.add('app-error');

            console.error(
                '[AVENTURA App] Application failed to initialize.',
                error
            );

            dispatch('app:error', { error });

        }finally{

            root.classList.remove('app-loading');

        }

    };

    /*----------------------------------------------
      Public Application API
    ----------------------------------------------*/

    AVENTURA.app = {
        init,

        get isInitialized(){
            return initialized;
        }
    };

    /*----------------------------------------------
      DOM Ready
    ----------------------------------------------*/

    if(document.readyState === 'loading'){

        document.addEventListener(
            'DOMContentLoaded',
            init,
            { once: true }
        );

    }else{

        init();

    }

})();