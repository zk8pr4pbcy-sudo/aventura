/*==================================================
  AVENTURA PLATFORM v2.0
  Modal Module
==================================================*/

'use strict';

window.AVENTURA = window.AVENTURA || {};

AVENTURA.modal = (() => {

    const { $$, addClass, removeClass } = AVENTURA.helpers;
    const { emit } = AVENTURA.events;
    const cls = AVENTURA.config.classes;

    let modals = [];
    let openButtons = [];
    let closeButtons = [];
    let activeModal = null;

    /*----------------------------------------------
      Init
    ----------------------------------------------*/

    const init = () => {

        modals = $$('[data-modal]');
        openButtons = $$('[data-modal-open]');
        closeButtons = $$('[data-modal-close]');

        if(!modals.length) return;

        bindEvents();

    };

    /*----------------------------------------------
      Events
    ----------------------------------------------*/

    const bindEvents = () => {

        openButtons.forEach(button => {

            button.addEventListener('click', () => {

                const id = button.dataset.modalOpen;

                open(id);

            });

        });

        closeButtons.forEach(button => {

            button.addEventListener('click', close);

        });

        modals.forEach(modal => {

            modal.addEventListener('click', event => {

                if(event.target === modal){
                    close();
                }

            });

        });

        document.addEventListener('keydown', event => {

            if(event.key === 'Escape'){
                close();
            }

        });

    };

    /*----------------------------------------------
      Open
    ----------------------------------------------*/

    const open = id => {

        const modal = document.getElementById(id);

        if(!modal) return;

        close();

        activeModal = modal;

        addClass(modal, cls.open);
        addClass(document.body, cls.locked);

        modal.setAttribute('aria-hidden', 'false');

        emit('modal:open', {
            id
        });

    };

    /*----------------------------------------------
      Close
    ----------------------------------------------*/

    const close = () => {

        if(!activeModal) return;

        removeClass(activeModal, cls.open);
        removeClass(document.body, cls.locked);

        activeModal.setAttribute('aria-hidden', 'true');

        emit('modal:close', {
            id: activeModal.id
        });

        activeModal = null;

    };

    /*----------------------------------------------
      Toggle
    ----------------------------------------------*/

    const toggle = id => {

        if(activeModal && activeModal.id === id){

            close();

            return;

        }

        open(id);

    };

    /*----------------------------------------------
      Return
    ----------------------------------------------*/

    return {

        init,

        open,

        close,

        toggle

    };

})();