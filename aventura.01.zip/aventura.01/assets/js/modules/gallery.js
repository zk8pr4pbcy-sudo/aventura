/*==================================================
  AVENTURA PLATFORM v2.0
  Gallery Module
==================================================*/

'use strict';

window.AVENTURA = window.AVENTURA || {};

AVENTURA.gallery = (() => {

    const { $$, addClass, removeClass } = AVENTURA.helpers;
    const { emit } = AVENTURA.events;
    const cls = AVENTURA.config.classes;

    let galleries = [];
    let activeIndex = 0;
    let activeItems = [];

    /*----------------------------------------------
      Init
    ----------------------------------------------*/

    const init = () => {

        galleries = $$('[data-gallery]');

        if(!galleries.length) return;

        galleries.forEach(gallery => {
            setupGallery(gallery);
        });

    };

    /*----------------------------------------------
      Setup
    ----------------------------------------------*/

    const setupGallery = gallery => {

        const items = $$('[data-gallery-item]', gallery);

        items.forEach((item, index) => {

            item.setAttribute('tabindex', '0');

            item.addEventListener('click', () => {
                openGallery(items, index);
            });

            item.addEventListener('keydown', event => {

                if(event.key === 'Enter' || event.key === ' '){
                    event.preventDefault();
                    openGallery(items, index);
                }

            });

        });

    };

    /*----------------------------------------------
      Open
    ----------------------------------------------*/

    const openGallery = (items, index = 0) => {

        activeItems = items;
        activeIndex = index;

        const item = activeItems[activeIndex];

        if(!item) return;

        addClass(document.body, cls.locked);

        emit('gallery:open', {
            index: activeIndex,
            item
        });

    };

    /*----------------------------------------------
      Close
    ----------------------------------------------*/

    const closeGallery = () => {

        removeClass(document.body, cls.locked);

        emit('gallery:close');

        activeItems = [];
        activeIndex = 0;

    };

    /*----------------------------------------------
      Next / Prev
    ----------------------------------------------*/

    const next = () => {

        if(!activeItems.length) return;

        activeIndex = (activeIndex + 1) % activeItems.length;

        emit('gallery:change', {
            index: activeIndex,
            item: activeItems[activeIndex]
        });

    };

    const prev = () => {

        if(!activeItems.length) return;

        activeIndex =
            (activeIndex - 1 + activeItems.length) % activeItems.length;

        emit('gallery:change', {
            index: activeIndex,
            item: activeItems[activeIndex]
        });

    };

    /*----------------------------------------------
      Keyboard
    ----------------------------------------------*/

    document.addEventListener('keydown', event => {

        if(!activeItems.length) return;

        if(event.key === 'Escape'){
            closeGallery();
        }

        if(event.key === 'ArrowRight'){
            next();
        }

        if(event.key === 'ArrowLeft'){
            prev();
        }

    });

    /*----------------------------------------------
      Return
    ----------------------------------------------*/

    return {
        init,
        open: openGallery,
        close: closeGallery,
        next,
        prev
    };

})();