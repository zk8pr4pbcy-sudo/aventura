/*==================================================
  AVENTURA PLATFORM v2.0
  Core DOM
==================================================*/

'use strict';

window.AVENTURA = window.AVENTURA || {};

AVENTURA.dom = (() => {

    const s = AVENTURA.config.selectors;

    /*----------------------------------------------
      Core
    ----------------------------------------------*/

    const body = document.body;

    const html = document.documentElement;

    const header = document.querySelector(s.header);

    /*----------------------------------------------
      Navigation
    ----------------------------------------------*/

    const navigation = document.querySelector(s.nav);

    const navigationToggle = document.querySelector(s.navToggle);

    const navigationClose = document.querySelector(s.navClose);

    /*----------------------------------------------
      Header
    ----------------------------------------------*/

    const backToTop = document.querySelector(s.backToTop);

    /*----------------------------------------------
      Components
    ----------------------------------------------*/

    const accordions = [...document.querySelectorAll(s.accordion)];

    const tabs = [...document.querySelectorAll(s.tabs)];

    const modals = [...document.querySelectorAll(s.modal)];

    const galleries = [...document.querySelectorAll(s.gallery)];

    const forms = [...document.querySelectorAll(s.form)];

    const dropdowns = [...document.querySelectorAll(s.dropdown)];

    /*----------------------------------------------
      Language
    ----------------------------------------------*/

    const languageSwitcher = document.querySelector(
        s.languageSwitcher
    );

    /*----------------------------------------------
      Dynamic Helpers
    ----------------------------------------------*/

    const one = selector =>
        document.querySelector(selector);

    const all = selector =>
        [...document.querySelectorAll(selector)];

    /*----------------------------------------------
      Return
    ----------------------------------------------*/

    return {

        body,

        html,

        header,

        navigation,

        navigationToggle,

        navigationClose,

        backToTop,

        accordions,

        tabs,

        modals,

        galleries,

        forms,

        dropdowns,

        languageSwitcher,

        one,

        all

    };

})();