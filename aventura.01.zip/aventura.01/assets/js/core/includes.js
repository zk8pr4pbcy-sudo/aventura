/*==================================================
  AVENTURA PLATFORM v2.0
  Core Includes
==================================================*/

'use strict';

window.AVENTURA = window.AVENTURA || {};

AVENTURA.includes = (() => {

    const selector = '[data-include]';

    let loadingPromise = null;
    let loaded = false;

    /*----------------------------------------------
      Dispatch Event
    ----------------------------------------------*/

    const dispatch = (eventName, detail = null) => {

        if(
            AVENTURA.events &&
            typeof AVENTURA.events.emit === 'function'
        ){
            AVENTURA.events.emit(eventName, detail);
        }

        document.dispatchEvent(
            new CustomEvent(
                `aventura:${eventName.replace(/:/g, '-')}`,
                { detail }
            )
        );

    };

    /*----------------------------------------------
      Fetch HTML
    ----------------------------------------------*/

    const fetchHtml = async filePath => {

        if(
            typeof filePath !== 'string' ||
            !filePath.trim()
        ){
            throw new TypeError(
                '[AVENTURA Includes] A valid include path is required.'
            );
        }

        const response = await fetch(filePath, {
            method: 'GET',
            headers: {
                Accept: 'text/html'
            },
            cache: 'no-cache'
        });

        if(!response.ok){
            throw new Error(
                `[AVENTURA Includes] Failed to load "${filePath}". ` +
                `HTTP status: ${response.status}`
            );
        }

        return response.text();

    };

    /*----------------------------------------------
      Load Single Include
    ----------------------------------------------*/

    const loadElement = async element => {

        if(!(element instanceof Element)){
            return {
                success: false,
                element: null,
                filePath: null
            };
        }

        const filePath = element
            .getAttribute('data-include')
            ?.trim();

        if(!filePath){
            element.removeAttribute('data-include');

            return {
                success: false,
                element,
                filePath: null
            };
        }

        element.classList.remove(
            'include-loaded',
            'include-error'
        );

        element.classList.add('include-loading');
        element.setAttribute('aria-busy', 'true');

        try{

            const html = await fetchHtml(filePath);

            element.innerHTML = html;
            element.removeAttribute('data-include');

            element.classList.remove(
                'include-loading',
                'include-error'
            );

            element.classList.add('include-loaded');
            element.setAttribute('aria-busy', 'false');

            dispatch('include:loaded', {
                element,
                filePath
            });

            return {
                success: true,
                element,
                filePath
            };

        }catch(error){

            /*
             * إزالة data-include ضرورية حتى لا تعيد
             * حلقة التحميل محاولة الملف الفاشل بلا نهاية.
             */
            element.removeAttribute('data-include');
            element.innerHTML = '';

            element.classList.remove('include-loading');
            element.classList.add('include-error');
            element.setAttribute('aria-busy', 'false');

            console.error(
                `[AVENTURA Includes] Unable to load "${filePath}".`,
                error
            );

            dispatch('include:error', {
                element,
                filePath,
                error
            });

            return {
                success: false,
                element,
                filePath,
                error
            };

        }

    };

    /*----------------------------------------------
      Load All Includes
    ----------------------------------------------*/

    const load = async () => {

        if(loadingPromise){
            return loadingPromise;
        }

        loadingPromise = (async () => {

            const root = document.documentElement;

            root.classList.remove(
                'includes-loaded',
                'includes-error'
            );

            root.classList.add('includes-loading');

            dispatch('includes:loading');

            const loadedElements = [];
            const failures = [];

            try{

                /*
                 * دعم المكونات المتداخلة:
                 * قد يحتوي الملف المحمّل على data-include آخر.
                 */
                while(true){

                    const includeElements = [
                        ...document.querySelectorAll(selector)
                    ];

                    if(!includeElements.length){
                        break;
                    }

                    const results = await Promise.all(
                        includeElements.map(loadElement)
                    );

                    results.forEach(result => {

                        if(result.success){
                            loadedElements.push(result.element);
                        }else if(result.error){
                            failures.push(result);
                        }

                    });

                }

                loaded = failures.length === 0;

                root.classList.add('includes-loaded');

                if(failures.length){
                    root.classList.add('includes-error');
                }

                /*
                 * عناصر تغيير اللغة تكون داخل الهيدر المحمّل،
                 * لذلك نحدّث حالتها بعد اكتمال المكونات.
                 */
                if(
                    AVENTURA.language &&
                    typeof AVENTURA.language.init === 'function'
                ){
                    AVENTURA.language.init();
                }

                dispatch('includes:ready', {
                    elements: loadedElements,
                    failures
                });

                return {
                    elements: loadedElements,
                    failures
                };

            }finally{

                root.classList.remove('includes-loading');
                loadingPromise = null;

            }

        })();

        return loadingPromise;

    };

    /*----------------------------------------------
      Reload Available Includes
    ----------------------------------------------*/

    const reload = async () => {

        loaded = false;

        return load();

    };

    /*----------------------------------------------
      Public API
    ----------------------------------------------*/

    return {
        load,
        reload,
        loadElement,
        fetchHtml,

        get isLoaded(){
            return loaded;
        },

        get isLoading(){
            return loadingPromise !== null;
        }
    };

})();