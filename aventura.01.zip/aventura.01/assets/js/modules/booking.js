/*==================================================
  AVENTURA PLATFORM v2.0
  Booking Module
==================================================*/

'use strict';

window.AVENTURA = window.AVENTURA || {};

AVENTURA.booking = (() => {

    const { $, $$, addClass, removeClass } = AVENTURA.helpers;
    const { emit } = AVENTURA.events;
    const cls = AVENTURA.config.classes;

    let bookingForms = [];
    let experienceSelects = [];
    let dateFields = [];

    /*----------------------------------------------
      Init
    ----------------------------------------------*/

    const init = () => {

        bookingForms = $$('[data-booking-form]');
        experienceSelects = $$('[data-booking-experience]');
        dateFields = $$('[data-booking-date]');

        if(!bookingForms.length && !experienceSelects.length) return;

        setupForms();
        setupExperienceSelectors();
        setupDateFields();

    };

    /*----------------------------------------------
      Setup Forms
    ----------------------------------------------*/

    const setupForms = () => {

        bookingForms.forEach(form => {

            form.addEventListener('submit', event => {
                handleBookingSubmit(event, form);
            });

        });

    };

    /*----------------------------------------------
      Experience Selectors
    ----------------------------------------------*/

    const setupExperienceSelectors = () => {

        experienceSelects.forEach(select => {

            select.addEventListener('change', () => {

                updateBookingSummary(select);

            });

        });

    };

    /*----------------------------------------------
      Date Fields
    ----------------------------------------------*/

    const setupDateFields = () => {

        const today = new Date().toISOString().split('T')[0];

        dateFields.forEach(field => {

            if(!field.min){
                field.min = today;
            }

        });

    };

    /*----------------------------------------------
      Booking Submit
    ----------------------------------------------*/

    const handleBookingSubmit = (event, form) => {

        event.preventDefault();

        if(AVENTURA.forms && !AVENTURA.forms.validate(form)){

            emit('booking:error', {
                form
            });

            return;

        }

        addClass(form, cls.loading);

        const data = getBookingData(form);

        emit('booking:submit', {
            form,
            data
        });

        setTimeout(() => {

            removeClass(form, cls.loading);
            addClass(form, cls.success);

            emit('booking:success', {
                form,
                data
            });

        }, 900);

    };

    /*----------------------------------------------
      Booking Summary
    ----------------------------------------------*/

    const updateBookingSummary = select => {

        const form = select.closest('form');
        if(!form) return;

        const summary = $('[data-booking-summary]', form);
        if(!summary) return;

        const selected = select.options[select.selectedIndex];

        summary.textContent = selected?.textContent || '';

        emit('booking:experience-change', {
            value: select.value,
            label: selected?.textContent || ''
        });

    };

    /*----------------------------------------------
      Data
    ----------------------------------------------*/

    const getBookingData = form => {

        const formData = new FormData(form);
        const data = {};

        formData.forEach((value, key) => {
            data[key] = value;
        });

        return data;

    };

    /*----------------------------------------------
      Return
    ----------------------------------------------*/

    return {
        init,
        data: getBookingData
    };

})();