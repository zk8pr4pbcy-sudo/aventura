/*==================================================
  AVENTURA PLATFORM v2.0
  Core Storage
==================================================*/

'use strict';

window.AVENTURA = window.AVENTURA || {};

AVENTURA.storage = (() => {

    /*----------------------------------------------
      Storage Availability
    ----------------------------------------------*/

    const isAvailable = () => {

        try{

            const testKey = '__aventura_storage_test__';

            localStorage.setItem(testKey, testKey);
            localStorage.removeItem(testKey);

            return true;

        }catch(error){

            console.warn(
                '[AVENTURA Storage] Local storage is unavailable.',
                error
            );

            return false;

        }

    };

    /*----------------------------------------------
      Set Value
    ----------------------------------------------*/

    const set = (key, value) => {

        if(!key || !isAvailable()){
            return false;
        }

        try{

            const payload = JSON.stringify({
                value,
                savedAt: Date.now()
            });

            localStorage.setItem(key, payload);

            return true;

        }catch(error){

            console.error(
                `[AVENTURA Storage] Failed to save "${key}".`,
                error
            );

            return false;

        }

    };

    /*----------------------------------------------
      Get Value
    ----------------------------------------------*/

    const get = (key, fallback = null) => {

        if(!key || !isAvailable()){
            return fallback;
        }

        try{

            const storedValue = localStorage.getItem(key);

            if(storedValue === null){
                return fallback;
            }

            const parsedValue = JSON.parse(storedValue);

            if(
                parsedValue &&
                Object.prototype.hasOwnProperty.call(
                    parsedValue,
                    'value'
                )
            ){
                return parsedValue.value;
            }

            return fallback;

        }catch(error){

            /*
             * دعم القيم القديمة المحفوظة كنص مباشر،
             * مثل اللغة التي كان يحفظها الكود السابق.
             */

            try{

                const legacyValue = localStorage.getItem(key);

                return legacyValue !== null
                    ? legacyValue
                    : fallback;

            }catch(readError){

                console.error(
                    `[AVENTURA Storage] Failed to read "${key}".`,
                    readError
                );

                return fallback;

            }

        }

    };

    /*----------------------------------------------
      Remove Value
    ----------------------------------------------*/

    const remove = key => {

        if(!key || !isAvailable()){
            return false;
        }

        try{

            localStorage.removeItem(key);

            return true;

        }catch(error){

            console.error(
                `[AVENTURA Storage] Failed to remove "${key}".`,
                error
            );

            return false;

        }

    };

    /*----------------------------------------------
      Check Value
    ----------------------------------------------*/

    const has = key => {

        if(!key || !isAvailable()){
            return false;
        }

        return localStorage.getItem(key) !== null;

    };

    /*----------------------------------------------
      Clear AVENTURA Values
    ----------------------------------------------*/

    const clear = () => {

        if(!isAvailable()){
            return false;
        }

        try{

            const keys = Object.values(
                AVENTURA.config?.storageKeys || {}
            );

            keys.forEach(key => {
                localStorage.removeItem(key);
            });

            return true;

        }catch(error){

            console.error(
                '[AVENTURA Storage] Failed to clear stored data.',
                error
            );

            return false;

        }

    };

    /*----------------------------------------------
      Public API
    ----------------------------------------------*/

    return {
        set,
        get,
        remove,
        has,
        clear,
        isAvailable
    };

})();