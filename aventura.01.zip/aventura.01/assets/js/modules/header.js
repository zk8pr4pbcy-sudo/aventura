/*==================================================
  AVENTURA PLATFORM v2.0
  Header Module
==================================================*/

'use strict';

window.AVENTURA = window.AVENTURA || {};

AVENTURA.header = (() => {

    const { $, addClass, removeClass } = AVENTURA.helpers;
    const { emit } = AVENTURA.events;
    const config = AVENTURA.config;
    const cls = config.classes;

    let header;
    let backToTop;
    let lastScrollY = 0;
    let ticking = false;

    const scrollOffset = 80;

    /*----------------------------------------------
      Init
    ----------------------------------------------*/

    const init = () => {

        header = $(config.selectors.header);
        backToTop = $(config.selectors.backToTop);

        if(!header && !backToTop) return;

        bindEvents();
        update();

    };

    /*----------------------------------------------
      Bind Events
    ----------------------------------------------*/

    const bindEvents = () => {

        window.addEventListener('scroll', onScroll, {
            passive: true
        });

        if(backToTop){
            backToTop.addEventListener('click', scrollTop);
        }

    };

    /*----------------------------------------------
      Scroll Handler
    ----------------------------------------------*/

    const onScroll = () => {

        lastScrollY = window.scrollY || window.pageYOffset;

        if(!ticking){

            window.requestAnimationFrame(() => {

                update();
                ticking = false;

            });

            ticking = true;

        }

    };

    /*----------------------------------------------
      Update Header
    ----------------------------------------------*/

    const update = () => {

        const isScrolled = lastScrollY > scrollOffset;

        if(header){

            if(isScrolled){
                addClass(header, cls.scrolled);
            }else{
                removeClass(header, cls.scrolled);
            }

        }

        if(backToTop){

            if(isScrolled){
                addClass(backToTop, cls.visible);
            }else{
                removeClass(backToTop, cls.visible);
            }

        }

        emit('header:update', {
            scrollY: lastScrollY,
            isScrolled
        });

    };

    /*----------------------------------------------
      Scroll Top
    ----------------------------------------------*/

    const scrollTop = event => {

        event.preventDefault();

        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });

    };

    /*----------------------------------------------
      Return
    ----------------------------------------------*/

    return {
        init,
        update
    };

})();