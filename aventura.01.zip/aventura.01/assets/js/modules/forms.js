/*==================================================
  AVENTURA PLATFORM v2.0
  Forms Module
==================================================*/

'use strict';

window.AVENTURA = window.AVENTURA || {};

AVENTURA.forms = (() => {

    const { $$, addClass, removeClass } = AVENTURA.helpers;
    const { emit } = AVENTURA.events;
    const cls = AVENTURA.config.classes;

    let forms = [];

    /*----------------------------------------------
      Init
    ----------------------------------------------*/

    const init = () => {

        forms = $$('[data-form]');

        if(!forms.length) return;

        forms.forEach(form => {
            setupForm(form);
        });

    };

    /*----------------------------------------------
      Setup
    ----------------------------------------------*/

    const setupForm = form => {

        form.setAttribute('novalidate', 'true');

        form.addEventListener('submit', event => {
            handleSubmit(event, form);
        });

        const fields = $$('input, textarea, select', form);

        fields.forEach(field => {

            field.addEventListener('input', () => {
                clearFieldState(field);
            });

            field.addEventListener('blur', () => {
                validateField(field);
            });

        });

    };

    /*----------------------------------------------
      Submit
    ----------------------------------------------*/

    const handleSubmit = (event, form) => {

        event.preventDefault();

        const isValid = validateForm(form);

        if(!isValid){

            emit('form:error', {
                form
            });

            return;

        }

        addClass(form, cls.loading);

        emit('form:submit', {
            form,
            data: getFormData(form)
        });

        setTimeout(() => {

            removeClass(form, cls.loading);
            addClass(form, cls.success);

            emit('form:success', {
                form
            });

        }, 800);

    };

    /*----------------------------------------------
      Validate Form
    ----------------------------------------------*/

    const validateForm = form => {

        const fields = $$('input, textarea, select', form);

        let valid = true;

        fields.forEach(field => {

            const fieldValid = validateField(field);

            if(!fieldValid){
                valid = false;
            }

        });

        return valid;

    };

    /*----------------------------------------------
      Validate Field
    ----------------------------------------------*/

    const validateField = field => {

        if(field.disabled || field.type === 'hidden') return true;

        const group = field.closest('.form-group');

        clearFieldState(field);

        if(field.required && !field.value.trim()){

            setFieldError(field, group);
            return false;

        }

        if(field.type === 'email' && field.value){

            const emailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(field.value);

            if(!emailValid){
                setFieldError(field, group);
                return false;
            }

        }

        if(field.type === 'tel' && field.value){

            const phoneValid = /^[0-9+\s()-]{7,20}$/.test(field.value);

            if(!phoneValid){
                setFieldError(field, group);
                return false;
            }

        }

        setFieldSuccess(field, group);

        return true;

    };

    /*----------------------------------------------
      States
    ----------------------------------------------*/

    const setFieldError = (field, group) => {

        addClass(field, 'is-invalid');

        if(group){
            addClass(group, 'is-error');
            removeClass(group, 'is-success');
        }

    };

    const setFieldSuccess = (field, group) => {

        addClass(field, 'is-valid');

        if(group){
            addClass(group, 'is-success');
            removeClass(group, 'is-error');
        }

    };

    const clearFieldState = field => {

        const group = field.closest('.form-group');

        removeClass(field, 'is-invalid');
        removeClass(field, 'is-valid');

        if(group){
            removeClass(group, 'is-error');
            removeClass(group, 'is-success');
        }

    };

    /*----------------------------------------------
      Data
    ----------------------------------------------*/

    const getFormData = form => {

        const formData = new FormData(form);
        const data = {};

        formData.forEach((value, key) => {
            data[key] = value;
        });

        return data;

    };

    /*----------------------------------------------
      Return
    ----------------------------------------------*/

    return {
        init,
        validate: validateForm,
        data: getFormData
    };

})();